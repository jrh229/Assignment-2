# CS 1501 Assignment Information Sheet

You must electronically submit an information sheet with
every assignment. Also be sure to submit all materials
following the procedures described in the assignment
description.

Name: ______________________________

Assignment #: ______________

Source code (.java) file name(s):

_________________________________________________________

_________________________________________________________

Does your program compile without errors?: _____________

If not, what is/are the error(s)?:

_________________________________________________________

_________________________________________________________

_________________________________________________________

Does your program run without errors?: _____________

If not, what is/are the error(s) and which parts of your
program run correctly?:

_________________________________________________________

_________________________________________________________

_________________________________________________________

_________________________________________________________


Additional comments (including problems and extra credit):
_________________________________________________________

_________________________________________________________

_________________________________________________________

_________________________________________________________
